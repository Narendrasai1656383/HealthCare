package com.OnlineAppointmentBookingSystem.dto;

public class AppointmentRequest {
	private String timeSlot;
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	public Long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Long doctorId) {
		this.doctorId = doctorId;
	}
	private Long doctorId;
}
