package com.OnlineAppointmentBookingSystem.exception;

public class EmailAlreadyExistsException extends Exception{
	public EmailAlreadyExistsException(String m) {
		super(m);
	}
}
